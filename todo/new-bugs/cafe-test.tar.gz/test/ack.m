fmod ACK2 is
  sort Nat .
  op 0 : -> Nat .
  op s : Nat -> Nat .
  op ack : Nat Nat -> Nat .
  vars I J : Nat .
  eq ack(0, J) = s(J) .
  eq ack(s(I), 0) = ack(I, s(0)) .
  eq ack(s(I), s(J)) = ack(I, ack(s(I), J)) .
endfm

red ack(s(s(s(0))), s(s(s(s(0))))) .
red ack(s(s(s(0))), s(s(s(s(s(0)))))) .
red ack(s(s(s(0))), s(s(s(s(s(s(0))))))) .
red ack(s(s(s(0))), s(s(s(s(s(s(s(0)))))))) .
red ack(s(s(s(0))), s(s(s(s(s(s(s(s(0))))))))) .
