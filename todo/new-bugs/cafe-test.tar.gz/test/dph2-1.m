*** translate [] -> //
*** translate [:=] -> /%/
***  Name[:=] -> /%/
***  Channel[:=] -> /%/C
***  Process[:=] -> /%/P
*** translate <|> -> ||
*** translate <,> -> ++
*** translate {}; -> #$

mod DININGROOM is

***  [Num < Primitive, Variable < Primitive < Name, Unit < Process,
***   Channel Empty < Channels]
  sorts Num Variable Primitive Name Channel Channels Unit Process Empty .
  subsort Num < Primitive .
  subsort Variable < Primitive .
  subsort Primitive < Name .
  subsort Unit < Process .
  subsort Channel < Channels .
  subsort Empty < Channels .

  var X : Variable .
  var PRIM : Primitive .
  vars L M N : Name .
  var CH : Channel .
  vars CS CS2 : Channels .
  var U : Unit .
  vars P Q R : Process .
  var I : Num .
  var B : Bool .

  *** Logic
  op and : Bool Bool -> Bool [assoc comm] .
  op or : Bool Bool -> Bool [assoc comm] .
  eq and(false, B) = false .
  eq and(true, true) = true .
  eq or(true, B) = true .
  eq or(false, false) = false .

  *** NUMBER
  ops 1 2 3 4 5 6 7 8 : -> Num .

  *** ACTION-on-FORK
  ops pickup putdown : -> Primitive .

  *** ACTION-on-SEAT
  ops sitdown getup : -> Primitive .

  *** NAME
  op // : Name Name -> Name .
  op /%/ : Name Variable Name -> Name .
  ceq /%/(PRIM, X, N) = N if PRIM == X .
  ceq /%/(PRIM, X, N) = PRIM if PRIM =/= X .
  eq /%/(//(L, M), X, N) = //(/%/(L, X, N), /%/(M, X, N)) .

  *** CHANNEL
  ops ? ! : Name -> Channel .
  op /%/C : Channel Variable Name -> Channel .
  eq /%/C(?(M), X, N) = ?(/%/(M, X, N)) .
  eq /%/C(!(M), X, N) = !(/%/(M, X, N)) .

  *** CHANNELS
  op * : -> Empty .
  op ++ : Channels Channels -> Channels [assoc comm id: *] .
  op /%/C : Channels Variable Name -> Channels .
  eq /%/C(*, X, N) = * .
  ceq /%/C(++(CH, CS), X, N) = ++(/%/C(CH, X, N), /%/C(CS, X, N))
	if CS =/= * .

  *** PROCESS
  op @ : -> Unit .
  op #$ : Channels Process -> Process .
  op /%/P : Process Variable Name -> Process .
  eq #$(*, @) = @ .
  eq #$(*, #$(CS, P)) = #$(CS, P) .
  eq /%/P(U, X, N) = U .
  eq /%/P(#$(CS, P), X, N) = #$(/%/C(CS, X, N), /%/P(P, X, N)) .

  *** COMPOSITION
  op || : Process Process -> Process [assoc comm id: @] .
  rl ||(#$(++(!(N), CS), P), #$(++(?(N), CS2), Q)) =>
	||(#$(CS, P), #$(CS2, Q)) .
  rl ||(#$(++(!(//(M, N)), CS), P), #$(++(?(//(M, X)), CS2), Q)) =>
	||(#$(CS, P), #$(CS2, /%/P(Q, X, N))) .
  crl ||(#$(++(!(N), CS), P), ||(#$(++(?(N), CS2), Q), R)) =>
	||(#$(CS, P), ||(#$(CS2, Q), R)) if R =/= @ .
  crl ||(#$(++(!(//(M, N)), CS), P), ||(#$(++(?(//(M,X)), CS2), Q), R)) =>
	||(#$(CS, P), ||(#$(CS2, /%/P(Q, X, N)), R)) if R =/= @ .
  ceq /%/P(||(P, Q), X, N) = ||(/%/P(P, X, N), /%/P(Q, X, N))
	if and((P =/= @), (Q =/= @)) .

  *** FORK
  op x : -> Variable .
  op FK : -> Unit .
  op fk : -> Process .
  eq fk = #$(?(//(pickup, x)), #$(?(//(putdown, x)), FK)) .
  eq #$(*, FK) = fk .

  *** SEAT
  op y : -> Variable .
  op ST : -> Unit .
  op st : -> Process .
  eq st = #$(?(//(sitdown, y)), #$(?(//(getup, y)), ST)) .
  eq #$(*, ST) = st .

  *** PHILOSOPHER
  op PH : -> Unit .
  op ph : Num -> Process .
  eq ph(I) = #$(!(//(sitdown, I)),
	       #$(++(!(//(pickup, I)), !(//(pickup, I))),
		 #$(++(!(//(putdown, I)), !(//(putdown, I))),
		   #$(!(//(getup, I)), PH)))) .

  op fk4 : -> Process .
  op ph4 : -> Process .
  op st4 : -> Process .
  eq fk4 = ||(fk, ||(fk, ||(fk, fk))) .
  eq ph4 = ||(ph(1), ||(ph(2), ||(ph(3), ph(4)))) .
  eq st4 = ||(st, ||(st, ||(st, st))) .

  op fk8 : -> Process .
  op ph8 : -> Process .
  op st8 : -> Process .
  eq fk8 = ||(fk, ||(fk, ||(fk, ||(fk, ||(fk, ||(fk, ||(fk, fk))))))) .
  eq ph8 = ||(ph(1), ||(ph(2), ||(ph(3), ||(ph(4), ||(ph(5), ||(ph(6), ||(ph(7), ph(8)))))))) .
  eq st8 = ||(st, ||(st, ||(st, ||(st, ||(st, ||(st, ||(st, st))))))) .

endm

rew ||(fk4, ||(ph4, st4)) .
*** rew ||(fk8, ||(ph8, st8)) .
