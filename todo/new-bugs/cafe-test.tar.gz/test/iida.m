mod NSORTING-STRG is
  protecting MACHINE-INT .
  sort Strg .
  subsort MachineInt < Strg .
  op d : Strg Strg -> Strg [assoc] .
  op null : -> Strg .
  var S : Strg .
  vars N N' : MachineInt .
  eq d(null, S) = S .
  eq d(S, null) = S .
  crl d(N, N') => d(N', N) if N' < N .
endm

rew d(10, 9, 8, 7, 6, 5, 4, 3, 2, 1) .
rew d(20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1) .
rew d(30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1) .
rew d(40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1) .
