#include <stdio.h>

int ncalls;

static int
ack(i, j)
int i;
int j;
{
    ncalls++;
    if (i == 0) {
	return j + 1;
    } else if (j == 0) {
	return ack(i - 1, 1);
    } else {
	return ack(i - 1, ack(i, j - 1));
    }
}

int
main(ac, av)
int ac;
char **av;
{
    int i, j, k;

    if (ac != 3) {
	fprintf(stderr, "usage: %s num1 num2\n", av[0]);
	exit(1);
    }
    i = atoi(av[1]);
    j = atoi(av[2]);
    ncalls = 0;
    k = ack(i, j);

    printf("ack(%d,%d) = %d (%d calls)\n", i, j, k, ncalls);
    return 0;
}
