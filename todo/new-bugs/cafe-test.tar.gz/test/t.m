fmod LOGIC is
  op and : Bool Bool -> Bool [assoc comm] .
  op or : Bool Bool -> Bool [assoc comm] .
  var X : Bool .
  eq and(false, X) = false .
  eq and(true, true) = true .
  eq or(true, X) = true .
  eq or(false, false) = false .
endfm
