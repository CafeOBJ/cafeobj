#! /usr/local/bin/perl5 -w

while (<DATA>) {
    # Convert operator names
    s(\|st8/0\?Process\|)(st8)g;
    s(\|ph8/0\?Process\|)(ph8)g;
    s(\|fk8/0\?Process\|)(fk8)g;
    s(\|st4/0\?Process\|)(st4)g;
    s(\|ph4/0\?Process\|)(ph4)g;
    s(\|fk4/0\?Process\|)(fk4)g;
    s(\|ph/1\?Process\|)(ph)g;
    s(\|PH/0\?Process\|)(PH)g;
    s(\|st/0\?Process\|)(st)g;
    s(\|ST/0\?Process\|)(ST)g;
    s(\|y/0\?Name\|)(y)g;
    s(\|fk/0\?Process\|)(fk)g;
    s(\|FK/0\?Process\|)(FK)g;
    s(\|x/0\?Name\|)(x)g;
    s(\|\\\|/2\?Process\|)(||)g;
    s(\|P%/3\?Process\|)(P%)g;
    s(\|#\$/2\?Process\|)(#\$)g;
    s(\|@/0\?Process\|)(@)g;
    s(\|&/2\?Channels\|)(&)g;
    s(\|\*/0\?Channels\|)(\*)g;
    s(\|C%/3\?Channels\|)(C%)g;
    s(\|!/1\?Channels\|)(!)g;
    s(\|\?/1\?Channels\|)(?)g;
    s(\|N%/3\?Name\|)(N%)g;
    s(\|//2\?Name\|)(//)g;
    s(\|getup/0\?Name\|)(getup)g;
    s(\|sitdown/0\?Name\|)(sitdown)g;
    s(\|putdown/0\?Name\|)(putdown)g;
    s(\|pickup/0\?Name\|)(pickup)g;
    s(\|8/0\?Name\|)(8)g;
    s(\|7/0\?Name\|)(7)g;
    s(\|6/0\?Name\|)(6)g;
    s(\|5/0\?Name\|)(5)g;
    s(\|4/0\?Name\|)(4)g;
    s(\|3/0\?Name\|)(3)g;
    s(\|2/0\?Name\|)(2)g;
    s(\|1/0\?Name\|)(1)g;

    # Convert sort names
    s(\|Num\.DININGROOM\|)(Num)g;
    s(\|Primitive\.DININGROOM\|)(Primitive)g;
    s(\|Variable\.DININGROOM\|)(Variable)g;
    s(\|Name\.DININGROOM\|)(Name)g;
    s(\|Unit\.DININGROOM\|)(Unit)g;
    s(\|Process\.DININGROOM\|)(Process)g;
    s(\|Channel\.DININGROOM\|)(Channel)g;
    s(\|Empty\.DININGROOM\|)(Empty)g;
    s(\|Channels\.DININGROOM\|)(Channels)g;

    print;
}

__END__
(init)
(use NAT-VALUE)
(sort |?Bool.TRUTH-VALUE| |Bool.TRUTH-VALUE| |Num.DININGROOM| |Primitive.DININGROOM| |Variable.DININGROOM| |?Name.DININGROOM| |Name.DININGROOM| |Unit.DININGROOM| |?Process.DININGROOM| |Process.DININGROOM| |Channel.DININGROOM| |Empty.DININGROOM| |?Channels.DININGROOM| |Channels.DININGROOM| |?Nat*.RWL| |Nat*.RWL|)

(sort-order (|Nat.NAT-VALUE| |Nat*.RWL|) (|Empty.DININGROOM| |Channels.DININGROOM|) (|Channel.DININGROOM| |Channels.DININGROOM|) (|Unit.DININGROOM| |Process.DININGROOM|) (|Variable.DININGROOM| |Primitive.DININGROOM|) (|Primitive.DININGROOM| |Name.DININGROOM|) (|Num.DININGROOM| |Primitive.DININGROOM|))

(sort-order (|Nat*.RWL| |?Nat*.RWL|) (|Channels.DININGROOM| |?Channels.DININGROOM|) (|Process.DININGROOM| |?Process.DININGROOM|) (|Name.DININGROOM| |?Name.DININGROOM|) (|Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|))
(op |st8/0?Process| nil |Process.DININGROOM| (0))
(op |ph8/0?Process| nil |Process.DININGROOM| (0))
(op |fk8/0?Process| nil |Process.DININGROOM| (0))
(op |st4/0?Process| nil |Process.DININGROOM| (0))
(op |ph4/0?Process| nil |Process.DININGROOM| (0))
(op |fk4/0?Process| nil |Process.DININGROOM| (0))
(op |ph/1?Process| (|Num.DININGROOM|) |Process.DININGROOM| (0 1 0))
(op |PH/0?Process| nil |Unit.DININGROOM| nil)
(op |st/0?Process| nil |Process.DININGROOM| (0))
(op |ST/0?Process| nil |Unit.DININGROOM| nil)
(op |y/0?Name| nil |Variable.DININGROOM| nil)
(op |fk/0?Process| nil |Process.DININGROOM| (0))
(op |FK/0?Process| nil |Unit.DININGROOM| nil)
(op |x/0?Name| nil |Variable.DININGROOM| nil)
(op |\|/2?Process| (|Process.DININGROOM| |Process.DININGROOM|) |Process.DININGROOM| (1 2 0) (:r-assoc (:id (|@/0?Process|)) :comm :assoc))
(op |P%/3?Process| (|Process.DININGROOM| |Variable.DININGROOM| |Name.DININGROOM|) |Process.DININGROOM| (1 0 2 3 0))
(op |#$/2?Process| (|Channels.DININGROOM| |Process.DININGROOM|) |Process.DININGROOM| (1 2 0))
(op |@/0?Process| nil |Unit.DININGROOM| nil)
(op |&/2?Channels| (|Channels.DININGROOM| |Channels.DININGROOM|) |Channels.DININGROOM| (1 2 0) (:r-assoc (:id (|*/0?Channels|)) :comm :assoc))
(op */0 nil |Nat*.RWL| nil (:constr))
(op |*/0?Channels| nil |Empty.DININGROOM| nil)
(op |C%/3?Channels| (|Channels.DININGROOM| |Variable.DININGROOM| |Name.DININGROOM|) |Channels.DININGROOM| (1 0 2 3 0))
(op |C%/3?Channels| (|Channel.DININGROOM| |Variable.DININGROOM| |Name.DININGROOM|) |Channel.DININGROOM| (1 2 3 0))
(op |!/1?Channels| (|Name.DININGROOM|) |Channel.DININGROOM| (1))
(op |?/1?Channels| (|Name.DININGROOM|) |Channel.DININGROOM| (1))
(op |N%/3?Name| (|Name.DININGROOM| |Variable.DININGROOM| |Name.DININGROOM|) |Name.DININGROOM| (1 0 2 3 0))
(op |//2?Name| (|Name.DININGROOM| |Name.DININGROOM|) |Name.DININGROOM| (1 2))
(op |getup/0?Name| nil |Primitive.DININGROOM| nil)
(op |sitdown/0?Name| nil |Primitive.DININGROOM| nil)
(op |putdown/0?Name| nil |Primitive.DININGROOM| nil)
(op |pickup/0?Name| nil |Primitive.DININGROOM| nil)
(op |8/0?Name| nil |Num.DININGROOM| nil)
(op |7/0?Name| nil |Num.DININGROOM| nil)
(op |6/0?Name| nil |Num.DININGROOM| nil)
(op |5/0?Name| nil |Num.DININGROOM| nil)
(op |4/0?Name| nil |Num.DININGROOM| nil)
(op |3/0?Name| nil |Num.DININGROOM| nil)
(op |2/0?Name| nil |Num.DININGROOM| nil)
(op |1/0?Name| nil |Num.DININGROOM| nil)
(op |false/0| nil |Bool.TRUTH-VALUE| nil (:constr))
(op |true/0| nil |Bool.TRUTH-VALUE| nil (:constr))
(op |_and_| (|Bool.TRUTH-VALUE| |Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0) (:r-assoc (:idr (|true/0|)) :comm :assoc))
(op |_or_| (|Bool.TRUTH-VALUE| |Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0) (:r-assoc (:idr (|false/0|)) :comm :assoc))
(op |_xor_| (|Bool.TRUTH-VALUE| |Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0) (:r-assoc (:idr (|false/0|)) :comm :assoc))
(op |not_| (|Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 0))
(op |_implies_| (|Bool.TRUTH-VALUE| |Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (0 1 2 0) (:r-assoc))
(op |ph/1?Process| (|?Name.DININGROOM|) |?Process.DININGROOM| (1 0))
(op |\|/2?Process| (|?Process.DININGROOM| |?Process.DININGROOM|) |?Process.DININGROOM| (1 2 0) (:r-assoc))
(op |P%/3?Process| (|?Process.DININGROOM| |?Name.DININGROOM| |?Name.DININGROOM|) |?Process.DININGROOM| (1 2 3 0))
(op |#$/2?Process| (|?Channels.DININGROOM| |?Process.DININGROOM|) |?Process.DININGROOM| (1 2 0))
(op |&/2?Channels| (|?Channels.DININGROOM| |?Channels.DININGROOM|) |?Channels.DININGROOM| (1 2 0) (:r-assoc))
(op |C%/3?Channels| (|?Channels.DININGROOM| |?Name.DININGROOM| |?Name.DININGROOM|) |?Channels.DININGROOM| (1 2 3 0))
(op |!/1?Channels| (|?Name.DININGROOM|) |?Channels.DININGROOM| (1 0))
(op |?/1?Channels| (|?Name.DININGROOM|) |?Channels.DININGROOM| (1 0))
(op |N%/3?Name| (|?Name.DININGROOM| |?Name.DININGROOM| |?Name.DININGROOM|) |?Name.DININGROOM| (1 2 3 0))
(op |//2?Name| (|?Name.DININGROOM| |?Name.DININGROOM|) |?Name.DININGROOM| (1 2 0))
(op |_and_| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 2 0) (:r-assoc))
(op |_or_| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 2 0) (:r-assoc))
(op |_xor_| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 2 0) (:r-assoc))
(op |not_| (|?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 0))
(op |_implies_| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 2 0) (:r-assoc))
(op |=/=-aux| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0))
(op |==-aux| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0))
(op |_=\\(_\\)=>_| (|?Bool.TRUTH-VALUE| |?Nat*.RWL| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (2 0))
(op _==>_ (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0))
(op _=/=_ (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0))
(op _==_ (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 2 0))
(op |if_then_else_fi| (|?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE| |?Bool.TRUTH-VALUE|) |?Bool.TRUTH-VALUE| (1 0))
(op |=/=-aux| (|?Name.DININGROOM| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |==-aux| (|?Name.DININGROOM| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |_=\\(_\\)=>_| (|?Name.DININGROOM| |?Nat*.RWL| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (2 0))
(op _==>_ (|?Name.DININGROOM| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _=/=_ (|?Name.DININGROOM| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _==_ (|?Name.DININGROOM| |?Name.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |if_then_else_fi| (|?Bool.TRUTH-VALUE| |?Name.DININGROOM| |?Name.DININGROOM|) |?Name.DININGROOM| (1 0))
(op |=/=-aux| (|?Process.DININGROOM| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |==-aux| (|?Process.DININGROOM| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |_=\\(_\\)=>_| (|?Process.DININGROOM| |?Nat*.RWL| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (2 0))
(op _==>_ (|?Process.DININGROOM| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _=/=_ (|?Process.DININGROOM| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _==_ (|?Process.DININGROOM| |?Process.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |if_then_else_fi| (|?Bool.TRUTH-VALUE| |?Process.DININGROOM| |?Process.DININGROOM|) |?Process.DININGROOM| (1 0))
(op |=/=-aux| (|?Channels.DININGROOM| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |==-aux| (|?Channels.DININGROOM| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |_=\\(_\\)=>_| (|?Channels.DININGROOM| |?Nat*.RWL| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (2 0))
(op _==>_ (|?Channels.DININGROOM| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _=/=_ (|?Channels.DININGROOM| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op _==_ (|?Channels.DININGROOM| |?Channels.DININGROOM|) |Bool.TRUTH-VALUE| (1 2 0))
(op |if_then_else_fi| (|?Bool.TRUTH-VALUE| |?Channels.DININGROOM| |?Channels.DININGROOM|) |?Channels.DININGROOM| (1 0))
(op |=/=-aux| (|?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (1 2 0))
(op |==-aux| (|?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (1 2 0))
(op |_=\\(_\\)=>_| (|?Nat*.RWL| |?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (2 0))
(op _==>_ (|?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (1 2 0))
(op _=/=_ (|?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (1 2 0))
(op _==_ (|?Nat*.RWL| |?Nat*.RWL|) |Bool.TRUTH-VALUE| (1 2 0))
(op |if_then_else_fi| (|?Bool.TRUTH-VALUE| |?Nat*.RWL| |?Nat*.RWL|) |?Nat*.RWL| (1 0))
(op |!if| (|Bool.TRUTH-VALUE|) |Bool.TRUTH-VALUE| (1 0))
(rule ((prim |Primitive.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|N%/3?Name| prim x n) n (((_==_ prim x) (|true/0|))))
(rule ((prim |Primitive.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|N%/3?Name| prim x n) prim (((_=/=_ prim x) (|true/0|))))
(rule ((l |Name.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|N%/3?Name| (|//2?Name| l m) x n) (|//2?Name| (|N%/3?Name| l x n) (|N%/3?Name| m x n)))
(rule ((m |Name.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|C%/3?Channels| (|?/1?Channels| m) x n) (|?/1?Channels| (|N%/3?Name| m x n)))
(rule ((m |Name.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|C%/3?Channels| (|!/1?Channels| m) x n) (|!/1?Channels| (|N%/3?Name| m x n)))
(rule ((x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|C%/3?Channels| (|*/0?Channels|) x n) (|*/0?Channels|))
(rule ((ch |Channel.DININGROOM|) (cs |Channels.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|C%/3?Channels| (|&/2?Channels| ch cs) x n) (|&/2?Channels| (|C%/3?Channels| ch x n) (|C%/3?Channels| cs x n)) (((_=/=_ cs (|*/0?Channels|)) (|true/0|))))
(rule nil (|#$/2?Process| (|*/0?Channels|) (|@/0?Process|)) (|@/0?Process|))
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|)) (|#$/2?Process| (|*/0?Channels|) (|#$/2?Process| cs p)) (|#$/2?Process| cs p))
(rule ((u |Unit.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|P%/3?Process| u x n) u)
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|P%/3?Process| (|#$/2?Process| cs p) x n) (|#$/2?Process| (|C%/3?Channels| cs x n) (|P%/3?Process| p x n)))
(rule ((p |Process.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (|P%/3?Process| (|\|/2?Process| p q) x n) (|\|/2?Process| (|P%/3?Process| p x n) (|P%/3?Process| q x n)) (((|_and_| (_=/=_ p (|@/0?Process|)) (_=/=_ q (|@/0?Process|))) (|true/0|))))
(rule nil (|fk/0?Process|) (|#$/2?Process| (|?/1?Channels| (|//2?Name| (|pickup/0?Name|) (|x/0?Name|))) (|#$/2?Process| (|?/1?Channels| (|//2?Name| (|putdown/0?Name|) (|x/0?Name|))) (|FK/0?Process|))))
(rule nil (|#$/2?Process| (|*/0?Channels|) (|FK/0?Process|)) (|fk/0?Process|))
(rule nil (|st/0?Process|) (|#$/2?Process| (|?/1?Channels| (|//2?Name| (|sitdown/0?Name|) (|y/0?Name|))) (|#$/2?Process| (|?/1?Channels| (|//2?Name| (|getup/0?Name|) (|y/0?Name|))) (|ST/0?Process|))))
(rule nil (|#$/2?Process| (|*/0?Channels|) (|ST/0?Process|)) (|st/0?Process|))
(rule ((i |Num.DININGROOM|)) (|ph/1?Process| i) (|#$/2?Process| (|!/1?Channels| (|//2?Name| (|sitdown/0?Name|) i)) (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| (|pickup/0?Name|) i)) (|!/1?Channels| (|//2?Name| (|pickup/0?Name|) i))) (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| (|putdown/0?Name|) i)) (|!/1?Channels| (|//2?Name| (|putdown/0?Name|) i))) (|#$/2?Process| (|!/1?Channels| (|//2?Name| (|getup/0?Name|) i)) (|PH/0?Process|))))))
(rule nil (|fk4/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|fk/0?Process|)))))
(rule nil (|ph4/0?Process|) (|\|/2?Process| (|ph/1?Process| (|1/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|2/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|3/0?Name|)) (|ph/1?Process| (|4/0?Name|))))))
(rule nil (|st4/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|st/0?Process|)))))
(rule nil (|fk8/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|\|/2?Process| (|fk/0?Process|) (|fk/0?Process|)))))))))
(rule nil (|ph8/0?Process|) (|\|/2?Process| (|ph/1?Process| (|1/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|2/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|3/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|4/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|5/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|6/0?Name|)) (|\|/2?Process| (|ph/1?Process| (|7/0?Name|)) (|ph/1?Process| (|8/0?Name|))))))))))
(rule nil (|st8/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|\|/2?Process| (|st/0?Process|) (|st/0?Process|)))))))))
(rule ((x-id |Process.DININGROOM|)) (|\|/2?Process| (|@/0?Process|) x-id) x-id)
(rule ((x-id |Channels.DININGROOM|)) (|&/2?Channels| (|*/0?Channels|) x-id) x-id)
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|#$/2?Process| (|?/1?Channels| n) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| (|*/0?Channels|) q))) (|true/0|))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|#$/2?Process| (|?/1?Channels| n) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| (|*/0?Channels|) q))) (|true/0|))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| cs2 q))) (|true/0|))
(rule ((m |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)))) (|true/0|))
(rule ((m |Name.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)))) (|true/0|))
(rule ((m |Name.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| cs2 (|P%/3?Process| q x n)))) (|true/0|))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| n) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) q) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| n) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) q) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| cs2 q) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((m |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((m |Name.DININGROOM|) (p |Process.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((m |Name.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| cs2 (|P%/3?Process| q x n)) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((m |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| cs2 (|P%/3?Process| q x n)) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| cs2 q) r))) (|true/0|) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((m |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (x |Variable.DININGROOM|) (n |Name.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| cs2 (|P%/3?Process| q x n)))) (|true/0|))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (_==>_ (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| cs2 q))) (|true/0|))
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (n |Name.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| cs2 q)))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| cs2 (|P%/3?Process| q x n))))
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (n |Name.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| cs2 q) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| cs2 (|P%/3?Process| q x n)) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| cs2 (|P%/3?Process| q x n)) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n)) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((p |Process.DININGROOM|) (n |Name.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| cs2 q) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((p |Process.DININGROOM|) (n |Name.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| n) q) r)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) q) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (n |Name.DININGROOM|) (q |Process.DININGROOM|) (r |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|\|/2?Process| (|#$/2?Process| (|?/1?Channels| n) q) r)) (|\|/2?Process| (|#$/2?Process| cs p) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) q) r)) (((_=/=_ r (|@/0?Process|)) (|true/0|))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| (|//2?Name| m x)) cs2) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| cs2 (|P%/3?Process| q x n))))
(rule ((n |Name.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| (|//2?Name| m n)) p) (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n))))
(rule ((n |Name.DININGROOM|) (cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (m |Name.DININGROOM|) (x |Variable.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| (|//2?Name| m n)) cs) p) (|#$/2?Process| (|?/1?Channels| (|//2?Name| m x)) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| (|*/0?Channels|) (|P%/3?Process| q x n))))
(rule ((p |Process.DININGROOM|) (n |Name.DININGROOM|) (cs2 |Channels.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|#$/2?Process| (|&/2?Channels| (|?/1?Channels| n) cs2) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| cs2 q)))
(rule ((p |Process.DININGROOM|) (n |Name.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|!/1?Channels| n) p) (|#$/2?Process| (|?/1?Channels| n) q)) (|\|/2?Process| (|#$/2?Process| (|*/0?Channels|) p) (|#$/2?Process| (|*/0?Channels|) q)))
(rule ((cs |Channels.DININGROOM|) (p |Process.DININGROOM|) (n |Name.DININGROOM|) (q |Process.DININGROOM|)) (|\|/2?Process| (|#$/2?Process| (|&/2?Channels| (|!/1?Channels| n) cs) p) (|#$/2?Process| (|?/1?Channels| n) q)) (|\|/2?Process| (|#$/2?Process| cs p) (|#$/2?Process| (|*/0?Channels|) q)))
(rule nil (|not_| (|true/0|)) (|false/0|))
(rule nil (|not_| (|false/0|)) (|true/0|))
(rule ((a |Bool.TRUTH-VALUE|)) (|_and_| (|false/0|) a) (|false/0|))
(rule ((a |Bool.TRUTH-VALUE|)) (|_or_| (|true/0|) a) (|true/0|))
(rule ((a |Bool.TRUTH-VALUE|) (b |Bool.TRUTH-VALUE|)) (|_implies_| a b) (|_or_| (|not_| a) b))
(rule nil (|_xor_| (|true/0|) (|true/0|)) (|false/0|))
(rule ((x-id |Bool.TRUTH-VALUE|)) (|_xor_| (|false/0|) x-id) x-id)
(rule ((x-id |Bool.TRUTH-VALUE|)) (|_or_| (|false/0|) x-id) x-id)
(rule ((x-id |Bool.TRUTH-VALUE|)) (|_and_| (|true/0|) x-id) x-id)
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (_==>_ x y) (|true/0|) (((|_=\\(_\\)=>_| x (*/0) y) (|true/0|))))
(rule ((x |?Bool.TRUTH-VALUE|)) (_==>_ x x) (|true/0|))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|!if| (|=/=-aux| x y)) (|true/0|))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|!if| (|==-aux| x y)) (|false/0|))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|=/=-aux| x y) (|false/0|) ((x y)))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (_=/=_ x y) (|!if| (|=/=-aux| x y)))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|==-aux| x y) (|true/0|) ((x y)))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (_==_ x y) (|!if| (|==-aux| x y)))
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|if_then_else_fi| (|false/0|) x y) y)
(rule ((x |?Bool.TRUTH-VALUE|) (y |?Bool.TRUTH-VALUE|)) (|if_then_else_fi| (|true/0|) x y) x)
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (_==>_ x y) (|true/0|) (((|_=\\(_\\)=>_| x (*/0) y) (|true/0|))))
(rule ((x |?Name.DININGROOM|)) (_==>_ x x) (|true/0|))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|!if| (|=/=-aux| x y)) (|true/0|))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|!if| (|==-aux| x y)) (|false/0|))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|=/=-aux| x y) (|false/0|) ((x y)))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (_=/=_ x y) (|!if| (|=/=-aux| x y)))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|==-aux| x y) (|true/0|) ((x y)))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (_==_ x y) (|!if| (|==-aux| x y)))
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|if_then_else_fi| (|false/0|) x y) y)
(rule ((x |?Name.DININGROOM|) (y |?Name.DININGROOM|)) (|if_then_else_fi| (|true/0|) x y) x)
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (_==>_ x y) (|true/0|) (((|_=\\(_\\)=>_| x (*/0) y) (|true/0|))))
(rule ((x |?Process.DININGROOM|)) (_==>_ x x) (|true/0|))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|!if| (|=/=-aux| x y)) (|true/0|))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|!if| (|==-aux| x y)) (|false/0|))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|=/=-aux| x y) (|false/0|) ((x y)))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (_=/=_ x y) (|!if| (|=/=-aux| x y)))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|==-aux| x y) (|true/0|) ((x y)))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (_==_ x y) (|!if| (|==-aux| x y)))
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|if_then_else_fi| (|false/0|) x y) y)
(rule ((x |?Process.DININGROOM|) (y |?Process.DININGROOM|)) (|if_then_else_fi| (|true/0|) x y) x)
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (_==>_ x y) (|true/0|) (((|_=\\(_\\)=>_| x (*/0) y) (|true/0|))))
(rule ((x |?Channels.DININGROOM|)) (_==>_ x x) (|true/0|))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|!if| (|=/=-aux| x y)) (|true/0|))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|!if| (|==-aux| x y)) (|false/0|))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|=/=-aux| x y) (|false/0|) ((x y)))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (_=/=_ x y) (|!if| (|=/=-aux| x y)))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|==-aux| x y) (|true/0|) ((x y)))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (_==_ x y) (|!if| (|==-aux| x y)))
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|if_then_else_fi| (|false/0|) x y) y)
(rule ((x |?Channels.DININGROOM|) (y |?Channels.DININGROOM|)) (|if_then_else_fi| (|true/0|) x y) x)
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (_==>_ x y) (|true/0|) (((|_=\\(_\\)=>_| x (*/0) y) (|true/0|))))
(rule ((x |?Nat*.RWL|)) (_==>_ x x) (|true/0|))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|!if| (|=/=-aux| x y)) (|true/0|))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|!if| (|==-aux| x y)) (|false/0|))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|=/=-aux| x y) (|false/0|) ((x y)))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (_=/=_ x y) (|!if| (|=/=-aux| x y)))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|==-aux| x y) (|true/0|) ((x y)))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (_==_ x y) (|!if| (|==-aux| x y)))
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|if_then_else_fi| (|false/0|) x y) y)
(rule ((x |?Nat*.RWL|) (y |?Nat*.RWL|)) (|if_then_else_fi| (|true/0|) x y) x)
(rule nil (|!if| (|false/0|)) (|false/0|))
(rule nil (|!if| (|true/0|)) (|true/0|))
(stat on)
(compile)
(stat on)
(trace on rewrite)
(reduce (|\|/2?Process| (|fk/0?Process|)
            (|\|/2?Process| (|fk/0?Process|)
                (|\|/2?Process| (|ph/1?Process| (|1/0?Name|))
                    (|\|/2?Process| (|ph/1?Process| (|2/0?Name|))
                        (|\|/2?Process| (|st/0?Process|)
                            (|st/0?Process|)))))))
