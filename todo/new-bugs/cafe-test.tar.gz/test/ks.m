fmod KNAPSACK is
  protecting MACHINE-INT .
  sort K .
  op c : MachineInt MachineInt -> MachineInt [assoc comm] .
  op knapsack3 : MachineInt MachineInt -> K .
  op solved : MachineInt -> K .
  
  vars X Y Z R SUM : MachineInt .
  ceq knapsack3(c(X, c(Y, c(Z, R))), SUM) =
	solved(c(X, c(Y, Z))) if ((X + Y) + Z) == SUM .
endfm

red knapsack3(c(0, c(1, c(3, c(4, c(7, c(13, c(19, c(23, 27)))))))), 19) .

fmod KNAPSACK2 is
  protecting MACHINE-INT .
  sorts NatSet K .
  subsort MachineInt < NatSet .
  op c : NatSet NatSet -> NatSet [assoc comm] .
  op knapsack3 : NatSet MachineInt -> K .
  op solved : NatSet -> K .
  
  vars X Y Z SUM : MachineInt .
  var R : NatSet .
  ceq knapsack3(c(X, c(Y, c(Z, R))), SUM) =
	solved(c(X, c(Y, Z))) if ((X + Y) + Z) == SUM .
endfm

red knapsack3(c(0, c(1, c(3, c(4, c(7, c(13, c(19, c(23, 27)))))))), 19) .
