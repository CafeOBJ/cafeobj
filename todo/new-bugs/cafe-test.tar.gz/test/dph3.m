*** translate [] -> //
*** translate [:=] -> /%/
*** translate <|> -> ||
*** translate <,> -> ++
*** translate {}; -> #$

mod DININGROOM is

***  [Num < Primitive, Variable < Primitive < Name, Unit < Process,
***   Channel Empty < Channels]
  sorts Num Variable Primitive Name Channel Channels Unit Process Empty .
  subsort Num < Primitive .
  subsort Variable < Primitive .
  subsort Primitive < Name .
  subsort Unit < Process .
  subsort Channel < Channels .
  subsort Empty < Channels .

  var X : Variable .
  var PRIM : Primitive .
  vars L M N : Name .
  var CH : Channel .
  vars CS CS2 : Channels .
  var U : Unit .
  vars P Q R : Process .
  var I : Num .
  var B : Bool .

  *** Logic
  op and : Bool Bool -> Bool [assoc comm] .
  op or : Bool Bool -> Bool [assoc comm] .
  eq and(false, B) = false .
  eq and(true, true) = true .
  eq or(true, B) = true .
  eq or(false, false) = false .

  *** NUMBER
  ops 1 2 3 4 5 6 7 8 : -> Num .

  *** ACTION-on-FORK
  ops pickup putdown : -> Primitive .

  *** ACTION-on-SEAT
  ops sitdown getup : -> Primitive .

  *** NAME
  op // : Name Name -> Name .
  op /%/ : Name Variable Name -> Name .
  ceq /%/(PRIM, X, N) = N if PRIM == X .
  ceq /%/(PRIM, X, N) = PRIM if PRIM =/= X .
  eq /%/(//(L, M), X, N) = //(/%/(L, X, N), /%/(M, X, N)) .

  *** CHANNEL
  ops ? ! : Name -> Channel .
  *** op /%/ : Channel Variable Name -> Channel .

endm
