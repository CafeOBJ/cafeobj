fmod FACT is
  sort N .
  op 0 : -> N .
  op s : N -> N .
  op + : N N -> N [assoc comm] .
  op * : N N -> N [assoc comm] .
  op fact : N -> N .
  vars X Y : N .
  eq +(X, 0) = X .
  eq +(X, s(Y)) = s(+(X, Y)) .
  eq *(X, 0) = 0 .
  eq *(X, s(Y)) = +(*(X, Y), X) .
  eq fact(0) = s(0) .
  eq fact(s(X)) = *(s(X), fact(X)) .
endfm

red fact(s(s(s(s(s(s(s(0)))))))) .
